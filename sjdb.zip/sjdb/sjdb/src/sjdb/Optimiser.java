package sjdb;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

public class Optimiser {
	private Estimator es = new Estimator();

	public Optimiser(Catalogue cat) {
	}

	public Operator optimise(Operator plan) {
		ArrayList<Select> attlist = new ArrayList<Select>(); //to store the attr=attr select
		ArrayList<Select> vallist = new ArrayList<Select>(); // to store the attr=val select
		ArrayList<Select> valls = new ArrayList<Select>(); //to store the attr=val select with children
		ArrayList<Select> attls = new ArrayList<Select>();//to store the attr=attr select with children
		ArrayList<Scan> R = new ArrayList<Scan>();      
		ArrayList<Operator> pr = new ArrayList<Operator>(); //to store the final result
		ArrayList<Join> jolist = new ArrayList<Join>();
		ArrayList<Project> pt = new ArrayList<Project>();
		ArrayList<Project> initial = new ArrayList<Project>();
		iter(plan, attlist, vallist, R, jolist, initial);

		plan=select_down(plan, attlist, vallist, valls, attls, R, pr, jolist, pt);
//		System.out.print(plan);
		System.out.print("\n");
		plan = reorder(plan);
//		System.out.print(plan);
		System.out.print("\n");
		if (plan instanceof Project ){
			plan = push_up(plan);
//			System.out.print(plan);
			System.out.print("\n");
			plan = push_down(plan);
//			System.out.print(plan);
		}
	
		return plan;
	}

	// Scan the tree
	public Operator iter(Operator op, ArrayList<Select> attlist, ArrayList<Select> vallist, ArrayList<Scan> R,
			ArrayList<Join> jolist, ArrayList<Project> initial) {
		if (op instanceof Scan) {
			R.add((Scan) op);
			return op;
		}
		if (op instanceof Select) {
			Boolean right = ((Select) op).getPredicate().equalsValue();
			if (right) {
				vallist.add(((Select) op));
			} else {
				attlist.add(((Select) op));
			}
		}
		if (op instanceof Join) {
			jolist.add((Join) op);
		}
		if (op instanceof Project) {
			initial.add((Project) op);
		}
		iter(op.getInputs().get(0), attlist, vallist, R, jolist, initial); // for the left subtrees
		if (op.getInputs().size() == 2) { // for the right subtrees
			iter(op.getInputs().get(1), attlist, vallist, R, jolist, initial);
		}
		return op;
	}

	// Move select down and Join  (select and select *)
	public Operator select_down(Operator plan, ArrayList<Select> attlist, ArrayList<Select> vallist,
			ArrayList<Select> valls, ArrayList<Select> attls, ArrayList<Scan> R, ArrayList<Operator> pr,
			ArrayList<Join> jolist, ArrayList<Project> pt) {
		// create select attr = val with children and delete the scan that already used
		if (vallist.size() == 0 && attlist.size() == 1 ) {
			pr.add(0,plan);
			pr.add(0, test(pr.get(0),R, attlist));
		} else if (vallist.size() == 1 && attlist.size() == 0 && R.size() == 1) {
			pr.add(plan);
		} else if (vallist.size() == 0 && attlist.size() == 0) {
			pr.add(plan);
		} else {
			int size = vallist.size();
			for (int k = 0; k < size; k++) {
				for (int i = 0; i < R.size(); i++) {
					for (int j = 0; j < vallist.size(); j++) {
						if (R.get(i).getRelation().getAttributes().contains(vallist.get(j).getPredicate().getLeftAttribute())) {
							Select se = new Select(R.get(i), vallist.get(j).getPredicate());
							es.visit(se);
							valls.add(se);
							R.remove(i);
							vallist.remove(j);
						}
					}
				}
			}

			// create select attr = attr with children and create join
			// and delete the attr = val and relaitons that already used in the
			// ArrayList
			if (attlist.size() == 0) {
				ArrayList<Product> pd = new ArrayList<Product>();
				for (int i=0; i<valls.size(); i++){
					if (valls.size() > 1) {
						Product pc = new Product(valls.get(i), valls.get(i+1));
						es.visit(pc);
						pd.add(pc);
						valls.remove(i);
						valls.remove(i);
						for (int j =0; j<valls.size(); j++){
							Product po = new Product(pd.get(0), valls.get(j));
							es.visit(po);
							valls.remove(j);
							pd.add(0, po);
						}
						for (int k=0; k<R.size(); k++){
							Product pu = new Product(pd.get(0), R.get(k));
							es.visit(pu);
							pd.add(0, pu);
						}
					} else {
						Product pro = new Product(valls.get(i),R.get(0));
						es.visit(pro);
						pd.add(0, pro);
						for (int n=1; n<R.size(); n++) {
							Product prod = new Product(pd.get(0),R.get(n));
							es.visit(prod);
							pd.add(0, prod);
							R.remove(n);
							valls.remove(i);
						}
					}
				}
				if (plan instanceof Project) {
					Project pe = new Project(pd.get(0), ((Project)plan).getAttributes());
					es.visit(pe);
					pr.add(0, pe);
				} else {
					pr.add(pd.get(0));
				}
				
			} else {
				while(1>0){
					int size1 = attlist.size();
					for (int l=0;l<size1;l++){ // create join with attr=val and attr-val
						for (int i = 0; i < attlist.size(); i++) {
							Attribute left = attlist.get(i).getPredicate().getLeftAttribute();
							Attribute right = attlist.get(i).getPredicate().getRightAttribute();
							Select s1 = null;
							s1 = attlist.get(i);
							for (int n = 0; n < valls.size(); n++) {
								if (valls.get(n).getOutput().getAttributes().contains(right)
										|| valls.get(n).getOutput().getAttributes().contains(left)) {
									ArrayList<Select> new_valls = new ArrayList<Select>();
									new_valls.addAll(valls);
									new_valls.remove(n);
									// valls.remove(n);
									for (int t = 0; t < new_valls.size(); t++) {
										if (new_valls.get(t).getOutput().getAttributes().contains(left)
												|| new_valls.get(t).getOutput().getAttributes().contains(right)) {
											Attribute left2 = s1.getPredicate().getLeftAttribute();
											Attribute right2 = s1.getPredicate().getRightAttribute();

											if (valls.get(n).getOutput().getAttributes().contains(left2)) {
												Join jn = new Join(valls.get(n), new_valls.get(t),s1.getPredicate());
												es.visit(jn);
												jolist.add(jn);
											} else {
												Predicate prd = new Predicate(right2, left2);
												Join jn = new Join(valls.get(n), new_valls.get(t), prd);
												es.visit(jn);
												jolist.add(jn);
											}
											new_valls.remove(t);
											valls = (ArrayList<Select>) new_valls.clone();
											attlist.remove(i);
											break;
										}
									}
									if (jolist.size()>0)
										break;
								}
							}
							if (jolist.size()>0)
								break;
						}
						if (jolist.size()>0)
							break;
					}
					if (jolist.size()>0)
						break;
					
					for (int l = 0; l < size1; l++) {// create join with attr=val and scan
					for (int i = 0; i < attlist.size(); i++) {
						Attribute left = attlist.get(i).getPredicate().getLeftAttribute();
						Attribute right = attlist.get(i).getPredicate().getRightAttribute();
						Select s1 = null;
						s1 = attlist.get(i);
						for (int j = 0; j < R.size(); j++) {
							if (R.get(j).getRelation().getAttributes().contains(right)
									|| R.get(j).getRelation().getAttributes().contains(left)) {
									for (int k = 0; k < valls.size(); k++) {
										//create join with attr=val(with children) and scan
										if (valls.get(k).getOutput().getAttributes().contains(right)
												|| valls.get(k).getOutput().getAttributes().contains(left)) {
											Attribute left2 = s1.getPredicate().getLeftAttribute();
											Attribute right2 = s1.getPredicate().getRightAttribute();
											Product pd = new Product(valls.get(k), R.get(j));
											es.visit(pd);
											Select se = new Select(pd, s1.getPredicate());
											es.visit(se);
											if (valls.get(k).getOutput().getAttributes().contains(left2)) {
												Join jn = new Join(valls.get(k), R.get(j), s1.getPredicate());
												es.visit(jn);
												jolist.add(jn);
											} else {
												Predicate prd = new Predicate(right2, left2);
												Join jn = new Join(valls.get(k), R.get(j), prd);
												es.visit(jn);
												jolist.add(jn);
											}
											attls.add(se);
											R.remove(j);
											valls.remove(k);
											attlist.remove(i);
											break;
										}
									}
									if (jolist.size()>0)
										break;			
							}
						}
			
						if (jolist.size()>0)
							break;
					}
					if (jolist.size()>0)
						break;
				}
					if (jolist.size()>0)
						break;
					
					for (int l = 0; l < size1; l++) {// create join with scan and scan
						for (int i = 0; i < attlist.size(); i++) {
							Attribute left = attlist.get(i).getPredicate().getLeftAttribute();
							Attribute right = attlist.get(i).getPredicate().getRightAttribute();
							Select s1 = null;
							s1 = attlist.get(i);
							ArrayList<Operator> cop_valls = new ArrayList<Operator>();
							cop_valls.addAll(valls);
							for (int j = 0; j < R.size(); j++) {
								if (R.get(j).getRelation().getAttributes().contains(right)
										|| R.get(j).getRelation().getAttributes().contains(left)) {
										//Create join with scan and scan
										ArrayList<Scan> R3 = new ArrayList<Scan>();
										R3.addAll(R);
										R3.remove(j);
										for (int m = 0; m < R3.size(); m++) {
											if (R3.get(m).getRelation().getAttributes().contains(right)
													|| R3.get(m).getRelation().getAttributes().contains(left)) {
												Attribute left2 = s1.getPredicate().getLeftAttribute();
												Attribute right2 = s1.getPredicate().getRightAttribute();
	
												if (R3.get(m).getRelation().getAttributes().contains(left2)) {
													Join jn = new Join(R3.get(m), R.get(j), s1.getPredicate());
													es.visit(jn);
													jolist.add(jn);
												} else {
													Predicate prd = new Predicate(right2, left2);
													Join jn = new Join(R3.get(m), R.get(j), prd);
													es.visit(jn);
													jolist.add(jn);
												}
												R3.remove(m);
												R = (ArrayList<Scan>)R3.clone();
												attlist.remove(i);
												break;
											}
										}
										//since get the join break the loop to next step
										if (jolist.size()>0)
											break;
									
//									cop_valls.addAll(valls);
								}
							}
							
							if (jolist.size()>0)
								break;
						}
						if (jolist.size()>0)
							break;
					}
					if (jolist.size()>0)
						break;
				}

				if (attlist.size() == 0 && jolist.size() != 0 ) { // For the q4.txt
					ArrayList<Product> pd_ls = new ArrayList<Product>();
					ArrayList<Operator> oper = new ArrayList<Operator>();
					oper.add(0, jolist.get(0));
					if(valls.size() != 0){
							Product pd = new Product(jolist.get(0), valls.get(0));
							es.visit(pd);
							pd_ls.add(0, pd);
							int size2 = valls.size();
							for (int k=0; k<size2; k++){
								for (int m=1; m<valls.size(); m++){
									Product pd1 = new Product(pd_ls.get(0), valls.get(m));
									es.visit(pd1);
									pd_ls.add(0, pd1);
									valls.remove(m);
							}
						}
						oper.add(0, pd_ls.get(0));
					}
					if (R.size() != 0){
						int size3 = R.size();
						for (int p=0; p<size3; p++){
							for (int t=0; t<R.size();t++){
								Product pd2 = new Product(oper.get(0),R.get(t));
								es.visit(pd2);
								pd_ls.add(0, pd2);
								R.remove(t);
							}
						}
						oper.add(0, pd_ls.get(0));
					}
					if(plan instanceof Project){
						Project po = new Project(oper.get(0), ((Project) plan).getAttributes()); 	
						es.visit(po);
						pr.add(po);
					} else {
						pr.add(oper.get(0));
					}
					
				} else {
					// create select attr=attr with join and
					// delete the attr = attr and relations that already used in the
					// ArrayList
					int size2 = attlist.size();
					for (int i = 0; i < size2; i++) {
						for (int j = 0; j < attlist.size(); j++) {
							Attribute left = attlist.get(j).getPredicate().getLeftAttribute();
							Attribute right = attlist.get(j).getPredicate().getRightAttribute();
							Join jn = null;
//							for (int k = 0; k < jolist.size(); k++) {
								if (jolist.get(0).getOutput().getAttributes().contains(left)
										|| jolist.get(0).getOutput().getAttributes().contains(right)) {
									for (int l = 0; l < R.size(); l++) {
										if (R.get(l).getRelation().getAttributes().contains(right)
												|| R.get(l).getRelation().getAttributes().contains(left)) {
											if (jolist.get(0).getOutput().getAttributes().contains(left)) {
												jn = new Join(jolist.get(0), R.get(l), attlist.get(j).getPredicate());
												es.visit(jn);
												jolist.add(0,jn);
												R.remove(l);
												attlist.remove(j);	
											} else {
												Predicate prd = new Predicate(right, left);
												jn = new Join(jolist.get(0), R.get(l), prd);
												es.visit(jn);
												jolist.add(0,jn);
												R.remove(l);
												attlist.remove(j);	
											}
										}
									}
									for (int m = 0; m < valls.size(); m++) {
										if (valls.get(m).getOutput().getAttributes().contains(right)
												|| valls.get(m).getOutput().getAttributes().contains(left)) {
											if (jolist.get(0).getOutput().getAttributes().contains(left)) {
												jn = new Join(jolist.get(0), valls.get(m), attlist.get(j).getPredicate());
												es.visit(jn);
												jolist.add(0,jn);
												valls.remove(m);
												attlist.remove(j);	
											} else {
												Predicate prd = new Predicate(right, left);
												jn = new Join(jolist.get(0), valls.get(m), prd);
												es.visit(jn);
												jolist.add(0,jn);
												valls.remove(m);
												attlist.remove(j);	
											}

										
										}
									}
								}
//							}
											
						}
				
						
					}
					if (R.size()!=0 || valls.size() != 0){
						int size3 = R.size();
						int size4 = valls.size();
						ArrayList<Operator> pd_ls = new ArrayList<Operator>();
						pd_ls.add(0, jolist.get(0));
						for (int q=0;q<size4; q++) {
							for (int t=0; t<valls.size();t++){
								Product pd2 = new Product(pd_ls.get(0),valls.get(t));
								es.visit(pd2);
								pd_ls.add(0, pd2);
								valls.remove(t);
							}
						}
						for (int p=0; p<size3; p++){
							for (int t=0; t<R.size();t++){
								Product pd2 = new Product(pd_ls.get(0),R.get(t));
								es.visit(pd2);
								pd_ls.add(0, pd2);
								R.remove(t);
							}
						}
						if (plan instanceof Project){
							Project pj = new Project(pd_ls.get(0), ((Project) plan).getAttributes()); 
							es.visit(pj);
							pr.add(0,pj);

						} else {
							pr.add(0,pd_ls.get(0));

						}	
					} else {
						if (plan instanceof Project){
							Project pj = new Project(jolist.get(0), ((Project) plan).getAttributes()); 
							es.visit(pj);
							pr.add(0,pj);

						} else {
							pr.add(0,jolist.get(0));

						}	
					}
				}
			}
			
		}
//		System.out.print(pr.get(0).toString());
		return pr.get(0);
	}


	public Operator test(Operator pr, ArrayList<Scan> R, ArrayList<Select> attlist) { // for create join when vallist.size() == 0 && attlist.size() == 1
		if (pr instanceof Project){
			crea_join(pr, R, attlist);
		}
		if (pr instanceof Select) {
			pr = crea(pr, R, attlist);
		}
		return pr;
	}
	
	public Operator crea_join(Operator pr, ArrayList<Scan> R, ArrayList<Select> attlist) { // for select
		Attribute left = attlist.get(0).getPredicate().getLeftAttribute();
		Attribute right = attlist.get(0).getPredicate().getRightAttribute();
		Scan left_re = null;
		Scan right_re = null;
		if (pr.getInputs().get(0) instanceof Select) {
			if (pr.getInputs().get(0).getInputs().get(0) instanceof Product){
				for (int i=0; i<R.size(); i++){
					if (R.get(i).getRelation().getAttributes().contains(left)) {
						left_re = R.get(i);
						R.remove(i);
					}
					if (R.get(i).getRelation().getAttributes().contains(right)) {
						right_re = R.get(i);
						R.remove(i);
					}		
				}
				Join jn = new Join(left_re, right_re, ((Select) pr.getInputs().get(0)).getPredicate());
				jn = reattr(jn);
				if (R.size() !=0) {
					ArrayList<Product> prd = new ArrayList<Product>();
					Product pd = new Product(jn, R.get(0));
					es.visit(pd);
					prd.add(0, pd);
					R.remove(0);
					if (R.size() !=0 ) {
						for (int j=0; j<R.size(); j++){
							Product pdt = new Product(prd.get(0), R.get(j));
							es.visit(pdt);
							prd.add(0, pdt);
							R.remove(j);	
						}
						pr.inputs.set(0, prd.get(0));
						return pr;
					} else {
						pr.inputs.set(0, prd.get(0));
						return pr;
					}			
				} else {
					pr.inputs.set(0, jn);
					return pr;
				}
			}
		}
		pr.inputs.set(0, crea_join(pr.getInputs().get(0),R, attlist));
		return pr;
	}
	public Operator crea(Operator pr, ArrayList<Scan> R, ArrayList<Select> attlist){ //for Select *
		
		Attribute left = attlist.get(0).getPredicate().getLeftAttribute();
		Attribute right = attlist.get(0).getPredicate().getRightAttribute();
		Scan left_re = null;
		Scan right_re = null;
		if (pr.getInputs().get(0) instanceof Product) {
				for (int i=0; i<R.size(); i++){
					if (R.get(i).getRelation().getAttributes().contains(left)) {
						left_re = R.get(i);
						R.remove(i);
					}
					if (R.get(i).getRelation().getAttributes().contains(right)) {
						right_re = R.get(i);
						R.remove(i);
					}		
				}
				Join jn = new Join(left_re, right_re, ((Select) pr).getPredicate());
				jn = reattr(jn);
				if (R.size() !=0) {
					ArrayList<Product> prd = new ArrayList<Product>();
					Product pd = new Product(jn, R.get(0));
					es.visit(pd);
					prd.add(0, pd);
					R.remove(0);
					if (R.size() !=0 ) {
						for (int j=0; j<R.size(); j++){
							Product pdt = new Product(prd.get(0), R.get(j));
							es.visit(pdt);
							prd.add(0, pdt);
							R.remove(j);	
						}
						return prd.get(0);
					} else {
						return prd.get(0);
					}			
				} else {
					return jn;
				}
		}
		pr.inputs.set(0, crea(pr.getInputs().get(0),R, attlist));
		return pr;
	}

	
	// Join Ordering
	public Operator reorder(Operator pr) {
		if (pr instanceof Scan) {	
			return pr;
		}
		pr.inputs.set(0, reorder(pr.getInputs().get(0)));
		if (pr instanceof Join)
			if (pr.getInputs().get(0) instanceof Join) {
				Attribute attr = ((Join)pr).getPredicate().getLeftAttribute();
				if (high(pr.getInputs().get(0).getInputs().get(0)) > high(pr.getInputs().get(1))){
					if(pr.getInputs().get(0).getInputs().get(0).getOutput().getAttributes().contains(attr)) {
						if (pr.getInputs().get(0).getInputs().get(1).getOutput().getTupleCount() > pr.getInputs().get(1).getOutput().getTupleCount()){
							Join second = null;
							second = new Join(pr.getInputs().get(0).getInputs().get(0), pr.getInputs().get(1), ((Join) pr).getPredicate());
							second = reattr(second);			
							Join first = new Join(second,pr.getInputs().get(0).getInputs().get(1),((Join)pr.getInputs().get(0)).getPredicate()) ;
							first = reattr(first);
							pr = first;
						}
					}
				} 
				else {
					if (pr.getInputs().get(0).getInputs().get(0).getOutput().getAttributes().contains(attr)){
						if (pr.getInputs().get(0).getInputs().get(1).getOutput().getTupleCount() > pr.getInputs().get(1).getOutput().getTupleCount()){
							Join second = null;
							second = new Join(pr.getInputs().get(0).getInputs().get(0), pr.getInputs().get(1), ((Join) pr).getPredicate());
							second = reattr(second);			
							Join first = new Join(second,pr.getInputs().get(0).getInputs().get(1),((Join)pr.getInputs().get(0)).getPredicate()) ;
							first = reattr(first);
							pr = first;
						}
					} else {
						if (pr.getInputs().get(0).getInputs().get(0).getOutput().getTupleCount() > pr.getInputs().get(1).getOutput().getTupleCount()){
							Join second = null;
							second = new Join(pr.getInputs().get(0).getInputs().get(1), pr.getInputs().get(1), ((Join) pr).getPredicate());
							second = reattr(second);			
							Join first = new Join(second,pr.getInputs().get(0).getInputs().get(0),((Join)pr.getInputs().get(0)).getPredicate()) ;
							first = reattr(first);
							pr = first;
						}
						
					}
				}
			}
		
		return pr;
	}
	// judge the high of the subtrees
	public int high(Operator pr){
		int h=0;
		while (pr.getInputs() != null) {
			h++;
			pr = pr.getInputs().get(0);
		}
		return h;
	}
	// reorder predicate 
	public Join reattr(Join pr){
		Attribute left = pr.getPredicate().getLeftAttribute();
		Attribute right = pr.getPredicate().getRightAttribute();
		Join jn = null;
		if (pr.getInputs().get(0).getOutput().getAttributes().contains(left)) {
			jn = new Join(pr.getInputs().get(0), pr.getInputs().get(1), pr.getPredicate());
			es.visit(jn);
		} else {
			Predicate prd = new Predicate(right, left);
			jn = new Join(pr.getInputs().get(0), pr.getInputs().get(1), prd);
			es.visit(jn);
		}
		return jn;
	}
	// Push Projection down
	// The push_up function will push the top project and join
		public Operator push_up(Operator pr) {
			if (pr instanceof Scan) {
				return pr;
			}
			if (pr.getInputs().get(0) instanceof Product){
				ArrayList<Attribute> left_ls = new ArrayList<Attribute>();
				ArrayList<Attribute> right_ls = new ArrayList<Attribute>();
				
				for (int i=0; i < pr.getOutput().getAttributes().size(); i++){
					if(pr.getInputs().get(0).getInputs().get(0).getOutput().getAttributes().contains(pr.getOutput().getAttributes().get(i))){
						left_ls.add(pr.getOutput().getAttributes().get(i));
//						Project prot_left = new Project(pr.getInputs().get(0).getInputs().get(0), left_ls);
//						es.visit(prot_left);
//						pr.getInputs().get(0).inputs.set(0, prot_left);
					} else {
						right_ls.add(pr.getOutput().getAttributes().get(i));
//						Project prot_right = new Project(pr.getInputs().get(0).getInputs().get(1), right_ls);
//						es.visit(prot_right);
//						pr.getInputs().get(0).inputs.set(1, prot_right);
					}
				}
				if (left_ls.size() != 0) {
					Project prot_left = new Project(pr.getInputs().get(0).getInputs().get(0), left_ls);
					es.visit(prot_left);
					pr.getInputs().get(0).inputs.set(0, prot_left);
				}
				if (right_ls.size() !=0 ){
					Project prot_right = new Project(pr.getInputs().get(0).getInputs().get(1), right_ls);
					es.visit(prot_right);
					pr.getInputs().get(0).inputs.set(1, prot_right);
				}
				
			}
			if (pr instanceof Join) {
				ArrayList<Attribute> left_ls = new ArrayList<Attribute>();
				ArrayList<Attribute> right_ls = new ArrayList<Attribute>();
				Attribute left = ((Join) pr).getPredicate().getLeftAttribute();
				Attribute right = ((Join) pr).getPredicate().getRightAttribute();
				left_ls.add(left);
				right_ls.add(right);
				Project pro_left = new Project(pr.getInputs().get(0), left_ls);
				es.visit(pro_left);
				Project pro_right = new Project(pr.getInputs().get(1), right_ls);
				es.visit(pro_right);
				pr.inputs.set(0, pro_left);
				pr.inputs.set(1, pro_right);
			}
			pr.inputs.set(0, push_up(pr.getInputs().get(0)));
			return pr;
		}
    // The push_down function will push the projects down that are created at push_up function
		public Operator push_down(Operator pr){
			if (pr instanceof Scan) {
				return pr;
			}
			if (pr instanceof Project){
				if (pr.getInputs().get(0) instanceof Join) {
					List<Attribute> rs = pr.getInputs().get(0).getInputs().get(1).getOutput().getAttributes();
					List<Attribute> ls = pr.getInputs().get(0).getInputs().get(0).getOutput().getAttributes();
					for (int i=0; i<pr.getOutput().getAttributes().size(); i++){
						List<Attribute> left_ls = null;
						List<Attribute> right_ls = null;
						
						if (pr.getInputs().get(0).getInputs().get(0).getInputs().get(0).getOutput().getAttributes().contains(pr.getOutput().getAttributes().get(i))) {
							left_ls = pr.getInputs().get(0).getInputs().get(0).getOutput().getAttributes();
							if (!left_ls.contains(pr.getOutput().getAttributes().get(i))) {
								ls.add(pr.getOutput().getAttributes().get(i));
								
							}			
						} else {
							right_ls = pr.getInputs().get(0).getInputs().get(1).getOutput().getAttributes();
							if (!right_ls.contains(pr.getOutput().getAttributes().get(i))) {
								rs.add(pr.getOutput().getAttributes().get(i));				
							}	
						}
					}
					Project pro_left = new Project(pr.getInputs().get(0).getInputs().get(0).getInputs().get(0), ls);
					Project pro_right = new Project(pr.getInputs().get(0).getInputs().get(1).getInputs().get(0), rs);
					es.visit(pro_right);
					pr.inputs.get(0).inputs.set(1, pro_right);
					es.visit(pro_left);
					pr.inputs.get(0).inputs.set(0, pro_left);
				} 
			}
		
			pr.inputs.set(0, push_down(pr.getInputs().get(0)));
			return pr;
		}
	
}
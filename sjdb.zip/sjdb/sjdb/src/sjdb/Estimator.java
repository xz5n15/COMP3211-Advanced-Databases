package sjdb;

import java.util.List;
import java.util.ArrayList;
import java.util.Iterator;

public class Estimator implements PlanVisitor {


	public Estimator() {
		// empty constructor
	}

	/* 
	 * Create output relation on Scan operator
	 *
	 * Example implementation of visit method for Scan operators.
	 */
	public void visit(Scan op) {
		Relation input = op.getRelation();
		Relation output = new Relation(input.getTupleCount());
		
		Iterator<Attribute> iter = input.getAttributes().iterator();
		while (iter.hasNext()) {
			output.addAttribute(new Attribute(iter.next()));
		}
		
		op.setOutput(output);
	}

	public void visit(Project op) {
		Relation input = op.getInput().getOutput();
		Relation output = new Relation(input.getTupleCount());
		
		Iterator<Attribute> iter = op.getAttributes().iterator();
		while (iter.hasNext()) {
			output.addAttribute(new Attribute(input.getAttribute(iter.next())));
		}
		
		op.setOutput(output);
	}
	
	public void visit(Select op) {
		/* For predicates of the form attr=val
		 * T(R)/V(R,A), V(select(R),A)=1
		 *
		 * For predicates of the for attr=attr
		 * T(R)/max(V(R,A),V(R,B)), V(select(R),A)=V(select(R),B)=min(V(R,A),V(R,B))
		 */
		Relation input = op.getInput().getOutput();
		Relation output;
		Attribute left = null;
		Attribute right = null;
		int left_count;
		int right_count;
		int val_num;
		
		left = input.getAttribute(op.getPredicate().getLeftAttribute());
		left_count = left.getValueCount();
		
		
		
		if(op.getPredicate().equalsValue()) {
			output = new Relation(input.getTupleCount()/left_count);
			val_num = 1;
		} else {
			right = input.getAttribute(op.getPredicate().getRightAttribute());
			right_count = right.getValueCount();
			output = new Relation(input.getTupleCount()/Math.max(left_count, right_count));
			val_num = Math.min(left_count, right_count);
		}
		
		Iterator<Attribute> iter = input.getAttributes().iterator();
		while (iter.hasNext()) {
			Attribute atr = iter.next();																																																				
			if (atr.equals(right)||atr.equals(left)) {//
				output.addAttribute(new Attribute(atr.getName(),val_num));
			} else {
				output.addAttribute(new Attribute(atr));
			}
			
		}
		
		op.setOutput(output);
		
	}
	
	public void visit(Product op) {
		Relation left = op.getLeft().getOutput();
		Relation right = op.getRight().getOutput();
		Relation output = new Relation(left.getTupleCount()*right.getTupleCount());
		
		Iterator<Attribute> iter_left = left.getAttributes().iterator();
		Iterator<Attribute> iter_right = right.getAttributes().iterator();
		while (iter_left.hasNext()) {
			output.addAttribute(new Attribute(iter_left.next()));
		}
		while (iter_right.hasNext()){
			output.addAttribute(new Attribute(iter_right.next()));
		}
		
		op.setOutput(output);
	}
	
	public void visit(Join op) {//add the situation the attributes are not a join attribute??????
		Relation left = op.getLeft().getOutput();
		Relation right = op.getRight().getOutput();
		Predicate p = op.getPredicate();
        int left_count = left.getAttribute(p.getLeftAttribute()).getValueCount();
        int right_count = right.getAttribute(p.getRightAttribute()).getValueCount();
        int val_num = Math.min(left_count, right_count);
        
        Relation output = new Relation(left.getTupleCount()*right.getTupleCount()/Math.max(left_count, right_count));
		
        Iterator<Attribute> iter_left = left.getAttributes().iterator();
        Iterator<Attribute> iter_right = right.getAttributes().iterator();
        while (iter_left.hasNext()) {
        	Attribute atr_left = iter_left.next();
        	if (atr_left.equals(p.getLeftAttribute())) {
        		output.addAttribute(new Attribute(atr_left.getName(), val_num));
        	} else {
        		output.addAttribute(new Attribute(atr_left));
        	}
        }
        while (iter_right.hasNext()) {
        	Attribute atr_right = iter_right.next();
        	if (atr_right.equals(p.getRightAttribute())) {
        		output.addAttribute(new Attribute(atr_right.getName(), val_num));
        	} else {
        		output.addAttribute(new Attribute(atr_right));
        	}
        }
        
		op.setOutput(output);
	}
}
